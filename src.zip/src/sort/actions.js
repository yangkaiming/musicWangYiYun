export function music(strs){
    return {
        type: 'MUSIC',
        strs
    }
}
export function musices(str){
    return {
        type: 'MUSICES',
        str
    }
}
