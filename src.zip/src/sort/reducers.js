import { combineReducers } from 'redux'
function musicStrs(state=[],action){
    switch(action.type){
        case 'MUSIC':return [action.strs]
        default:return state
    }
}
function musicStr(state=[],action){
    switch(action.type){
        case 'MUSICES':return [action.str]
        default:return state
    }
}


export default combineReducers({
    musicStrs,musicStr
})