import React from 'react';
import ReacthOM from 'react-dom';
import App from './app'
ReacthOM.render(
    <div style={{ height: '100%' }}>
        <App />
    </div>
    , document.getElementById('root'))
